<ul class="nav masthead-nav">
<li class="active"><a href="#">Home</a></li>
<li><a href="#">A Empresa</a></li>
<li><a href="#">Serviços</a></li>
<li><a href="#">Trabalhe Conosco</a></li>
<li><a href="#">Fale Conosco</a></li>
</ul>

<?php if($this->router->class() == 'Institucional' && $this->router->method() == 'index'){?>
<ul class="nav masthead-nav">
<?php } else {?>
<ul class="nav navbar-nav">
<?php } ?>

<li class="<?=($this->router->fetch_class() == 'Institucional' && $this->router->fetch_method() == 'index') ? 'active' : null; ?>"><a href="<?=base_url()?>" >Home</a></li>
<li class="<?=($this->router->fetch_class() == 'Institucional' && $this->router->fetch_method() == 'Empresa') ?'active' : null; ?>"><a href="<?=base_url('empresa')?>" >A Empresa</a></li>
<li class="<?=($this->router->fetch_class() == 'Institucional' && $this->router->fetch_method() == 'Servicos') ?'active' : null; ?>"><a href="<?=base_url('servicos')?>">Serviços</a></li>
<li class="<?=($this->router->fetch_class() == 'Contato' && $this->router->fetch_method() == 'TrabalheConosco')? 'active' : null; ?>"><a href="<?=base_url('trabalhe-conosco')?>">Trabalhe Conosco</a></li>
<li class="<?=($this->router->fetch_class() == 'Contato' && $this->router->fetch_method() == 'FaleConosco') ? 'active' : null; ?>"><a href="<?=base_url('fale-conosco')?>">Fale Conosco</a></li>